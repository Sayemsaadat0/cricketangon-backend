export type ICategoryFilter = {
    searchTerm:string
    name?: string
  }

  export const CategorySearchableFields = [
    "name",
  ]

  export const CategoryFilterableFields = [
    "searhTerm",
    "name",
   
  ]

  