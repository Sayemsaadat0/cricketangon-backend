export type IPhotos = {
  image?: string
  category: 'regular' | 'moment'
}
