export type IStats={
    authorName:string;
    title:string;
    image?:string;
    description:string;
}